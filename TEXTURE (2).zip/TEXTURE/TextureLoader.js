var texture = new THREE.TextureLoader().load( 'texture.basis' );


var material = new THREE.MeshBasicMaterial( { map: texture } );